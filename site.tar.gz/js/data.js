/**
 * data.js — 全局数据层
 * 我现在火气很大 H5
 * LocalStorage 读写封装 + 用户/好友/数值/聊天核心逻辑
 */
(function(window) {
  'use strict';

  const LS = {
    get(key) {
      try { return JSON.parse(localStorage.getItem(key)); } catch(e) { return null; }
    },
    set(key, value) {
      localStorage.setItem(key, JSON.stringify(value));
    },
    remove(key) {
      localStorage.removeItem(key);
    }
  };

  const UserDB = {
    _KEY: 'huoqi_users',

    all() {
      return LS.get(this._KEY) || [];
    },
    _save(users) {
      LS.set(this._KEY, users);
    },
    findById(id) {
      return this.all().find(u => u.id === id) || null;
    },
    findByPhone(phone) {
      return this.all().find(u => u.phone === phone) || null;
    },
    register(phone, password, nickname, avatar) {
      const users = this.all();
      if (users.find(u => u.phone === phone)) {
        return { success: false, error: '该手机号已注册' };
      }
      const newUser = {
        id: 'U' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase(),
        phone: phone,
        password: password,
        nickname: nickname || ('用户' + phone.slice(-4)),
        avatar: avatar || '😊',
        avatarFrame: 'default',
        anger: 0,
        tolerance: 0,
        title: '',
        registerDate: new Date().toISOString().split('T')[0],
        dailyTolerance: {},
        createdAt: Date.now()
      };
      users.push(newUser);
      this._save(users);
      return { success: true, user: newUser };
    },
    login(phone, password) {
      const user = this.findByPhone(phone);
      if (!user) return { success: false, error: '手机号未注册' };
      if (user.password !== password) return { success: false, error: '密码错误' };
      LS.set('huoqi_current_user', user.id);
      return { success: true, user: user };
    },
    current() {
      const uid = LS.get('huoqi_current_user');
      if (!uid) return null;
      return this.findById(uid);
    },
    update(userId, fields) {
      const users = this.all();
      const idx = users.findIndex(u => u.id === userId);
      if (idx === -1) return false;
      Object.assign(users[idx], fields);
      this._save(users);
      return true;
    },
    logout() {
      LS.remove('huoqi_current_user');
    },
    search(keyword) {
      const users = this.all();
      return users.filter(u => u.phone === keyword || u.id === keyword)
        .map(u => ({
          id: u.id, nickname: u.nickname, avatar: u.avatar,
          avatarFrame: u.avatarFrame, anger: u.anger, tolerance: u.tolerance
        }));
    }
  };

  const FriendDB = {
    _KEY: 'huoqi_friends',
    MAX_FRIENDS: 50,

    _all() { return LS.get(this._KEY) || {}; },
    _save(data) { LS.set(this._KEY, data); },
    getFriends(userId) {
      const data = this._all();
      const friendIds = data[userId] || [];
      return friendIds.map(id => UserDB.findById(id)).filter(Boolean);
    },
    isFriend(userA, userB) {
      const data = this._all();
      return (data[userA] || []).includes(userB) && (data[userB] || []).includes(userA);
    },
    addFriend(userA, userB) {
      const data = this._all();
      if (!data[userA]) data[userA] = [];
      if (!data[userB]) data[userB] = [];
      if (data[userA].length >= this.MAX_FRIENDS || data[userB].length >= this.MAX_FRIENDS) {
        return { success: false, error: '好友已达上限(50人)' };
      }
      if (!data[userA].includes(userB)) data[userA].push(userB);
      if (!data[userB].includes(userA)) data[userB].push(userA);
      this._save(data);
      return { success: true };
    },
    removeFriend(userA, userB) {
      const data = this._all();
      if (data[userA]) data[userA] = data[userA].filter(id => id !== userB);
      if (data[userB]) data[userB] = data[userB].filter(id => id !== userA);
      this._save(data);
    },
    count(userId) {
      return (this._all()[userId] || []).length;
    }
  };

  const RequestDB = {
    _KEY: 'huoqi_friend_requests',
    _all() { return LS.get(this._KEY) || {}; },
    _save(data) { LS.set(this._KEY, data); },
    send(fromUserId, toUserId) {
      const data = this._all();
      if (!data[toUserId]) data[toUserId] = [];
      const existing = data[toUserId].find(r => r.from === fromUserId && r.status === 'pending');
      if (existing) return { success: false, error: '已发送过申请' };
      if (FriendDB.isFriend(fromUserId, toUserId)) return { success: false, error: '已是好友' };
      data[toUserId].push({ from: fromUserId, to: toUserId, status: 'pending', timestamp: Date.now() });
      this._save(data);
      return { success: true };
    },
    getPending(userId) {
      return (this._all()[userId] || []).filter(r => r.status === 'pending');
    },
    respond(toUserId, fromUserId, action) {
      const data = this._all();
      const list = data[toUserId] || [];
      const req = list.find(r => r.from === fromUserId && r.status === 'pending');
      if (!req) return { success: false, error: '申请不存在或已处理' };
      if (action === 'accept') {
        req.status = 'accepted';
        this._save(data);
        return FriendDB.addFriend(fromUserId, toUserId);
      }
      req.status = 'rejected';
      this._save(data);
      return { success: true };
    }
  };

  const ValueEngine = {
    clickAvatar(operatorId, targetId) {
      const operator = UserDB.findById(operatorId);
      const target = UserDB.findById(targetId);
      if (!operator || !target) return { success: false, error: '用户不存在' };
      if (operatorId === targetId) return { success: false, error: '不能操作自己' };
      const operatorAnger = operator.anger || 0;
      let targetAngerChange, effectType;
      if (operatorAnger >= 999) {
        targetAngerChange = -1; effectType = 'love';
      } else {
        targetAngerChange = 1; effectType = 'hit';
      }
      const newTargetAnger = Math.max(0, (target.anger || 0) + targetAngerChange);
      const newOperatorTolerance = (operator.tolerance || 0) + 1;
      UserDB.update(targetId, { anger: newTargetAnger });
      UserDB.update(operatorId, { tolerance: newOperatorTolerance });
      this._updateDailyTolerance(operatorId, newOperatorTolerance);
      return { success: true, effectType, targetNewAnger: newTargetAnger, operatorNewTolerance: newOperatorTolerance, operatorAngerTriggered: operatorAnger >= 999 };
    },
    longPressAvatar(operatorId, targetId) {
      const operator = UserDB.findById(operatorId);
      const target = UserDB.findById(targetId);
      if (!operator || !target) return { success: false, error: '用户不存在' };
      if (operatorId === targetId) return { success: false, error: '不能操作自己' };
      const newTargetAnger = Math.max(0, (target.anger || 0) - 1);
      const newOperatorTolerance = (operator.tolerance || 0) + 1;
      UserDB.update(targetId, { anger: newTargetAnger });
      UserDB.update(operatorId, { tolerance: newOperatorTolerance });
      this._updateDailyTolerance(operatorId, newOperatorTolerance);
      return { success: true, effectType: 'love', targetNewAnger: newTargetAnger, operatorNewTolerance: newOperatorTolerance };
    },
    _updateDailyTolerance(userId, newValue) {
      const user = UserDB.findById(userId);
      if (!user) return;
      const today = new Date().toISOString().split('T')[0];
      const daily = user.dailyTolerance || {};
      if (!daily[today] || newValue > daily[today]) daily[today] = newValue;
      UserDB.update(userId, { dailyTolerance: daily, tolerance: newValue });
    }
  };

  const ChatDB = {
    _key(userA, userB) {
      const ids = [userA, userB].sort();
      return 'huoqi_chat_' + ids[0] + '_' + ids[1];
    },
    getMessages(userA, userB) { return LS.get(this._key(userA, userB)) || []; },
    send(fromUserId, toUserId, text) {
      if (!text || !text.trim()) return { success: false, error: '消息不能为空' };
      const key = this._key(fromUserId, toUserId);
      const messages = LS.get(key) || [];
      messages.push({ from: fromUserId, to: toUserId, text: text.trim(), timestamp: Date.now() });
      LS.set(key, messages);
      return { success: true, message: messages[messages.length - 1] };
    },
    clear(userA, userB) { LS.remove(this._key(userA, userB)); }
  };

  const WeeklyEngine = {
    getCurrentWeek() {
      const now = new Date();
      const day = now.getDay();
      const monday = new Date(now);
      monday.setDate(now.getDate() - (day === 0 ? 6 : day - 1));
      const dates = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        dates.push(d.toISOString().split('T')[0]);
      }
      return { monday: dates[0], sunday: dates[6], dates };
    },
    checkWeeklyQualify(userId) {
      const user = UserDB.findById(userId);
      if (!user) return false;
      const week = this.getCurrentWeek();
      const daily = user.dailyTolerance || {};
      return week.dates.every(date => (daily[date] || 0) >= 999);
    },
    getQualifiedUsers() {
      return UserDB.all().filter(u => this.checkWeeklyQualify(u.id))
        .sort((a, b) => (b.tolerance || 0) - (a.tolerance || 0))
        .map(u => ({ id: u.id, nickname: u.nickname, tolerance: u.tolerance, avatar: u.avatar, avatarFrame: u.avatarFrame, title: '最值得交往的朋友' }));
    }
  };

  const ShopEngine = {
    items: [
      { id: 'frame_calm',     name: '心如止水',   cost: 200, frameClass: 'calm',     emoji: '🪷', desc: '水流莲花 · 心澄如镜' },
      { id: 'frame_bamboo',   name: '虚怀若竹',   cost: 280, frameClass: 'bamboo',   emoji: '🎋', desc: '翠竹清风 · 谦谦君子' },
      { id: 'frame_capybara', name: '卡皮巴拉',   cost: 350, frameClass: 'capybara', emoji: '🦫', desc: '淡定水豚 · 情绪稳定' },
      { id: 'frame_cloud',    name: '云淡风轻',   cost: 420, frameClass: 'cloud',    emoji: '☁️', desc: '飘逸白云 · 宠辱不惊' },
      { id: 'frame_master',   name: '包容大师',   cost: 500, frameClass: 'master',   emoji: '🌊', desc: '海纳百川 · 有容乃大' },
      { id: 'frame_smile',    name: '弥勒笑颜',   cost: 650, frameClass: 'smile',    emoji: '😊', desc: '慈眉善目 · 笑口常开' },
      { id: 'frame_zen',      name: '上善若水',   cost: 999, frameClass: 'zen',      emoji: '💧', desc: '终极形态 · 水滴石穿' }
    ],
    canAccess(userId) {
      const user = UserDB.findById(userId);
      return user && (user.tolerance || 0) >= 999;
    },
    purchase(userId, itemId) {
      const user = UserDB.findById(userId);
      if (!user) return { success: false, error: '用户不存在' };
      const item = this.items.find(i => i.id === itemId);
      if (!item) return { success: false, error: '商品不存在' };
      if ((user.tolerance || 0) < item.cost) return { success: false, error: '包容值不足' };
      if (user.avatarFrame === item.frameClass) return { success: false, error: '已拥有该头像框' };
      UserDB.update(userId, { tolerance: user.tolerance - item.cost, avatarFrame: item.frameClass });
      return { success: true };
    }
  };

  const CoolDownTips = [
    '🥒 来碗丝瓜汤，清热降火，一身轻松',
    '🍵 泡杯菊花茶，静心养性，怒气消散',
    '🧘 闭上眼睛深呼吸3次，让火气随风而去',
    '🚶 出门散步10分钟，换个心情再回来',
    '🎵 听一首治愈音乐，让心静下来',
    '📿 莫生气莫生气，气出病来无人替',
    '🌿 点一炷檀香，让烟雾带走你的火气',
    '🛁 泡个热水澡，把烦恼和火气一起泡走',
    '😌 原谅别人，就是善待自己',
    '💚 每一点包容，都会让世界更温柔'
  ];

  function getRandomTip() {
    return CoolDownTips[Math.floor(Math.random() * CoolDownTips.length)];
  }

  window.HQ = { UserDB, FriendDB, RequestDB, ValueEngine, ChatDB, WeeklyEngine, ShopEngine, getRandomTip, LS };
})(window);
